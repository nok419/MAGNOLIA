import type {
  AreaMaster,
  BulletPattern,
  ClassifiedContentKind,
  ConditionId,
  ConditionSpec,
  ContentBundle,
  ContentClassification,
  ContentIdMigrationMap,
  EffectSpec,
  EffectId,
  EnemyArchetype,
  EnemyId,
  EquipmentId,
  EquipmentMaster,
  HitboxPresetId,
  MapId,
  MissionId,
  MissionMaster,
  ProjectileId,
  ProjectileSpec,
  SignalProfile,
  TranscriptChunk,
  TranscriptChunkId,
  TransmissionId,
  TransmissionMaster,
  VisualPresetId,
  WorldMapLogic,
} from "@magnolia/contracts"
import { type PresentationCueId } from "@magnolia/contracts"
import areaBroadcastFacilityJson from "../../../content/gameplay/areas/area_broadcast_facility.json"
import areaCentralTowerJson from "../../../content/gameplay/areas/area_central_tower.json"
import bpA2LanceSpreadJson from "../../../content/gameplay/bullet-patterns/bp_a2_lance_spread.json"
import bpB1CoreBurstJson from "../../../content/gameplay/bullet-patterns/bp_b1_core_burst.json"
import bpB1LanceStreamJson from "../../../content/gameplay/bullet-patterns/bp_b1_lance_stream.json"
import bpC1PressureRingJson from "../../../content/gameplay/bullet-patterns/bp_c1_pressure_ring.json"
import bpHeavyBurstJson from "../../../content/gameplay/bullet-patterns/bp_heavy_burst.json"
import bpRadialBurstJson from "../../../content/gameplay/bullet-patterns/bp_radial_burst.json"
import bpScoutSingleJson from "../../../content/gameplay/bullet-patterns/bp_scout_single.json"
import bpSpiralStreamJson from "../../../content/gameplay/bullet-patterns/bp_spiral_stream.json"
import bpStandardSpreadJson from "../../../content/gameplay/bullet-patterns/bp_standard_spread.json"
import enemyA1Json from "../../../content/gameplay/enemies/a1.json"
import enemyA2Json from "../../../content/gameplay/enemies/a2.json"
import enemyB1Json from "../../../content/gameplay/enemies/b1.json"
import enemyC1Json from "../../../content/gameplay/enemies/c1.json"
import enemyHeavyJson from "../../../content/gameplay/enemies/enemy_heavy.json"
import enemyScoutJson from "../../../content/gameplay/enemies/enemy_scout.json"
import enemyStandardJson from "../../../content/gameplay/enemies/enemy_standard.json"
import effMainCarrierJson from "../../../content/gameplay/equipment/effects/eff_main_carrier.json"
import effMainPulseJson from "../../../content/gameplay/equipment/effects/eff_main_pulse.json"
import effOsMagnoliaJson from "../../../content/gameplay/equipment/effects/eff_os_magnolia.json"
import effSubNoiseCancellerJson from "../../../content/gameplay/equipment/effects/eff_sub_noise_canceller.json"
import effSubSilentWaveJson from "../../../content/gameplay/equipment/effects/eff_sub_silent_wave.json"
import effSubsystemAnalysisCircuitJson from "../../../content/gameplay/equipment/effects/eff_subsystem_analysis_circuit.json"
import effSubsystemGuidedWaveJson from "../../../content/gameplay/equipment/effects/eff_subsystem_guided_wave.json"
import effSubsystemInversePhaseJson from "../../../content/gameplay/equipment/effects/eff_subsystem_inverse_phase.json"
import effSubsystemNoiseGateJson from "../../../content/gameplay/equipment/effects/eff_subsystem_noise_gate.json"
import effSubsystemPrecisionControlJson from "../../../content/gameplay/equipment/effects/eff_subsystem_precision_control.json"
import eqMainCarrierJson from "../../../content/gameplay/equipment/eq_main_carrier.json"
import eqMainPulseJson from "../../../content/gameplay/equipment/eq_main_pulse.json"
import eqOsBrokenJson from "../../../content/gameplay/equipment/eq_os_broken.json"
import eqOsMagnoliaJson from "../../../content/gameplay/equipment/eq_os_magnolia.json"
import eqSubNoiseCancellerJson from "../../../content/gameplay/equipment/eq_sub_noise_canceller.json"
import eqSubSilentWaveJson from "../../../content/gameplay/equipment/eq_sub_silent_wave.json"
import eqSubsystemAnalysisCircuitJson from "../../../content/gameplay/equipment/eq_subsystem_analysis_circuit.json"
import eqSubsystemGuidedWaveJson from "../../../content/gameplay/equipment/eq_subsystem_guided_wave.json"
import eqSubsystemInversePhaseJson from "../../../content/gameplay/equipment/eq_subsystem_inverse_phase.json"
import eqSubsystemNoiseGateJson from "../../../content/gameplay/equipment/eq_subsystem_noise_gate.json"
import eqSubsystemPrecisionControlJson from "../../../content/gameplay/equipment/eq_subsystem_precision_control.json"
import worldMapDemoJson from "../../../content/gameplay/map-logic/world_map_demo.json"
import missionGoodMorningJson from "../../../content/gameplay/missions/mission_good_morning.json"
import missionWhereAreYouJson from "../../../content/gameplay/missions/mission_where_are_you.json"
import missionEvacuationJson from "../../../content/gameplay/missions/mission_evacuation.json"
import condAlwaysJson from "../../../content/gameplay/progression/conditions/cond_always.json"
import condMissionGoodMorningClearedJson from "../../../content/gameplay/progression/conditions/cond_mission_good_morning_cleared.json"
import contentClassificationJson from "../../../content/gameplay/content-classification.json"
import migratedIdMapJson from "../../../content/gameplay/migrated-id-map.json"
import projEnemyBasicJson from "../../../content/gameplay/projectiles/proj_enemy_basic.json"
import projEnemyCoreJson from "../../../content/gameplay/projectiles/proj_enemy_core.json"
import projEnemyGeoJson from "../../../content/gameplay/projectiles/proj_enemy_geo.json"
import projEnemyLanceJson from "../../../content/gameplay/projectiles/proj_enemy_lance.json"
import projEnemyPetalJson from "../../../content/gameplay/projectiles/proj_enemy_petal.json"
import projPlayerCarrierJson from "../../../content/gameplay/projectiles/proj_player_carrier.json"
import projPlayerCarrierBlastJson from "../../../content/gameplay/projectiles/proj_player_carrier_blast.json"
import projPlayerPulseJson from "../../../content/gameplay/projectiles/proj_player_pulse.json"
import projPlayerPulseMeleeJson from "../../../content/gameplay/projectiles/proj_player_pulse_melee.json"
import txGoodMorningChunksJson from "../../../content/gameplay/transmissions/tx_good_morning.chunks.json"
import txGoodMorningJson from "../../../content/gameplay/transmissions/tx_good_morning.json"
import txWhereAreYouChunksJson from "../../../content/gameplay/transmissions/tx_where_are_you.chunks.json"
import txWhereAreYouJson from "../../../content/gameplay/transmissions/tx_where_are_you.json"
import txEvacuationChunksJson from "../../../content/gameplay/transmissions/tx_evacuation.chunks.json"
import txEvacuationJson from "../../../content/gameplay/transmissions/tx_evacuation.json"
import {
  createDefaultDifficultyModifiers,
  createDefaultHitboxes,
  createDefaultPlayerShipSpec,
  createDefaultPresentationCues,
  createDefaultThemes,
  createDefaultVisuals,
} from "./defaults"

let cachedBundle: ContentBundle | null = null
// mission ごとの差は content 側の調整で吸収し、runtime へ専用分岐を増やし過ぎないための許可一覧です。
// frontend / art チームが敵配置や hazard を触る時は、まずこの generic schema の範囲で表現します。
const SUPPORTED_ENEMY_BEHAVIOR_KINDS = new Set(["straightDown", "zigzag", "slowDescent"])
const SUPPORTED_BULLET_PATTERN_KINDS = new Set(["goldenStream", "radial", "spread"])
const SUPPORTED_ENEMY_OVERRIDE_KEYS = new Set([
  "speed",
  "driftX",
  "wobbleAmplitude",
  "wobblePeriodMs",
  "pauseAtY",
  "pauseMs",
])
const SUPPORTED_TRANSCRIPT_IMPORTANCE = new Set(["normal", "important", "critical"])

export function loadContentBundle(): ContentBundle {
  if (cachedBundle) {
    return cachedBundle
  }

  // いまは content-tools 未導入のため、実データ JSON を明示 import して bundle を組み立てます。
  // 生成済み bundle に切り替える時は、この関数の内部だけを差し替えれば済む構成に留めます。
  const contentClassification = contentClassificationJson as ContentClassification
  const migratedIds = migratedIdMapJson as ContentIdMigrationMap
  const areas = [areaBroadcastFacilityJson, areaCentralTowerJson] as AreaMaster[]
  const transmissions = [txGoodMorningJson, txWhereAreYouJson, txEvacuationJson] as TransmissionMaster[]
  const transcriptChunks = [
    ...(txGoodMorningChunksJson as TranscriptChunk[]),
    ...(txWhereAreYouChunksJson as TranscriptChunk[]),
    ...(txEvacuationChunksJson as TranscriptChunk[]),
  ]
  const mapLogic = [worldMapDemoJson as WorldMapLogic]
  const allMissions = [
    missionGoodMorningJson,
    missionWhereAreYouJson,
    missionEvacuationJson,
  ] as MissionMaster[]
  const allEnemies = [
    enemyA1Json,
    enemyA2Json,
    enemyC1Json,
    enemyB1Json,
    enemyHeavyJson,
    enemyScoutJson,
    enemyStandardJson,
  ] as EnemyArchetype[]
  const allBulletPatterns = [
    bpA2LanceSpreadJson,
    bpC1PressureRingJson,
    bpB1CoreBurstJson,
    bpB1LanceStreamJson,
    bpHeavyBurstJson,
    bpRadialBurstJson,
    bpScoutSingleJson,
    bpSpiralStreamJson,
    bpStandardSpreadJson,
  ] as BulletPattern[]
  const allProjectiles = [
    projEnemyBasicJson,
    projEnemyCoreJson,
    projEnemyGeoJson,
    projEnemyLanceJson,
    projEnemyPetalJson,
    projPlayerCarrierJson,
    projPlayerCarrierBlastJson,
    projPlayerPulseJson,
    projPlayerPulseMeleeJson,
  ] as ProjectileSpec[]
  // runtime は active content だけを bundle に入れます。
  // prototype は validator と docs の対象に残し、mission へ混入した場合は missing reference として止めます。
  const missions = filterActiveContent(
    "missions",
    allMissions,
    "missionId",
    contentClassification,
  )
  const enemies = filterActiveContent(
    "enemies",
    allEnemies,
    "enemyId",
    contentClassification,
  )
  const bulletPatterns = filterActiveContent(
    "bullet-patterns",
    allBulletPatterns,
    "bulletPatternId",
    contentClassification,
  )
  const projectiles = filterActiveContent(
    "projectiles",
    allProjectiles,
    "projectileId",
    contentClassification,
  )
  const equipment = [
    eqMainCarrierJson,
    eqMainPulseJson,
    eqOsBrokenJson,
    eqOsMagnoliaJson,
    eqSubNoiseCancellerJson,
    eqSubSilentWaveJson,
    eqSubsystemAnalysisCircuitJson,
    eqSubsystemGuidedWaveJson,
    eqSubsystemInversePhaseJson,
    eqSubsystemNoiseGateJson,
    eqSubsystemPrecisionControlJson,
  ] as EquipmentMaster[]
  const effects = [
    effMainCarrierJson,
    effMainPulseJson,
    effOsMagnoliaJson,
    effSubNoiseCancellerJson,
    effSubSilentWaveJson,
    effSubsystemAnalysisCircuitJson,
    effSubsystemGuidedWaveJson,
    effSubsystemInversePhaseJson,
    effSubsystemNoiseGateJson,
    effSubsystemPrecisionControlJson,
  ] as EffectSpec[]
  const conditions = [
    condAlwaysJson,
    condMissionGoodMorningClearedJson,
  ] as ConditionSpec[]

  const bundle: ContentBundle = {
    playerShipSpec: createDefaultPlayerShipSpec(),
    areas: indexBy("areaId", areas),
    mapLogic: indexBy("mapId", mapLogic),
    transmissions: indexBy("transmissionId", transmissions),
    transcriptChunks: indexBy("chunkId", transcriptChunks),
    missions: indexBy("missionId", missions),
    enemies: indexBy("enemyId", enemies),
    bulletPatterns: indexBy("bulletPatternId", bulletPatterns),
    projectiles: indexBy("projectileId", projectiles),
    equipment: indexBy("equipmentId", equipment),
    effects: indexBy("effectId", effects),
    conditions: indexBy("conditionId", conditions),
    visuals: createDefaultVisuals(collectVisualPresetIds(missions, enemies, projectiles)),
    hitboxes: filterHitboxes(collectHitboxPresetIds(enemies, projectiles)),
    themes: createDefaultThemes(areas.map((area) => area.themeId)),
    presentationCues: filterPresentationCues([
      "system.boot.message",
      "system.reboot.sequence",
      "system.reboot.settle",
      "tutorial.restriction.enter",
      "tutorial.restriction.release",
      "explore.player.trail",
      "transmission.connect.sequence",
      "warp.transition.sequence",
      "battle.player.hit",
      "battle.noise.peak",
      "battle.noise.clear",
      "battle.invincible.start",
    ]),
    difficultyModifiers: createDefaultDifficultyModifiers(),
    contentClassification,
    migratedIds,
  }

  validateBundle(bundle)
  cachedBundle = bundle
  return bundle
}

function filterActiveContent<
  Item extends Record<Key, string>,
  Key extends keyof Item,
>(
  kind: ClassifiedContentKind,
  items: Item[],
  key: Key,
  classification: ContentClassification,
): Item[] {
  const activeIds = new Set<string>(classification.active[kind])
  const knownIds = new Set<string>(items.map((item) => String(item[key])))

  for (const activeId of activeIds) {
    if (!knownIds.has(activeId)) {
      throw new Error(`Active ${kind} id ${activeId} is not present in content files.`)
    }
  }

  return items.filter((item) => activeIds.has(String(item[key])))
}

function collectVisualPresetIds(
  missions: MissionMaster[],
  enemies: EnemyArchetype[],
  projectiles: ProjectileSpec[],
): VisualPresetId[] {
  const ids = new Set<VisualPresetId>()

  for (const mission of missions) {
    ids.add(mission.backgroundPresetId)
    for (const hazard of mission.hazards) {
      ids.add(hazard.visualPresetId)
    }
  }

  for (const enemy of enemies) {
    ids.add(enemy.visualPresetId)
  }

  for (const projectile of projectiles) {
    ids.add(projectile.visualPresetId)
  }

  return [...ids]
}

function collectHitboxPresetIds(
  enemies: EnemyArchetype[],
  projectiles: ProjectileSpec[],
): HitboxPresetId[] {
  const ids = new Set<HitboxPresetId>(["hitbox_player_core"])

  for (const enemy of enemies) {
    ids.add(enemy.hitboxPresetId)
  }

  for (const projectile of projectiles) {
    ids.add(projectile.hitboxPresetId)
  }

  return [...ids]
}

function filterHitboxes(ids: HitboxPresetId[]) {
  const hitboxes = createDefaultHitboxes()
  const filtered: Record<string, (typeof hitboxes)[string]> = {}

  for (const id of ids) {
    const hitbox = hitboxes[id]
    if (hitbox) {
      filtered[id] = hitbox
    }
  }

  return filtered
}

function filterPresentationCues(ids: PresentationCueId[]) {
  const cues = createDefaultPresentationCues()
  const filtered: Record<string, (typeof cues)[string]> = {}

  for (const id of ids) {
    filtered[id] = cues[id]
  }

  return filtered
}

function validateBundle(bundle: ContentBundle): void {
  const validSpawnPointIds = new Set([
    "spawn_player_center",
    "spawn_top_left",
    "spawn_top_center",
    "spawn_top_right",
    "spawn_mid_left",
    "spawn_mid_right",
    "spawn_side_left",
    "spawn_side_right",
  ])
  const validNodeIds = new Set<string>()
  const areaMapIds = new Set<string>()

  for (const mapLogic of Object.values(bundle.mapLogic)) {
    for (const node of [
      ...mapLogic.areaNodes,
      ...mapLogic.transmissionNodes,
      ...mapLogic.warpNodes,
      ...mapLogic.collectibleNodes,
    ]) {
      validNodeIds.add(node.nodeId)
    }
  }

  for (const area of Object.values(bundle.areas)) {
    areaMapIds.add(area.mapId)
    if (!bundle.mapLogic[area.mapId]) {
      throw new Error(`Missing map ${area.mapId} for area ${area.areaId}.`)
    }
    assertConditionExists(bundle, area.unlockConditionId, `area ${area.areaId}`)
    assertConditionExists(bundle, area.visibilityConditionId, `area ${area.areaId}`)

    for (const transmissionId of area.transmissionIds) {
      const transmission = bundle.transmissions[transmissionId]
      if (!transmission) {
        throw new Error(`Missing transmission ${transmissionId} for area ${area.areaId}.`)
      }
      if (transmission.areaId !== area.areaId) {
        throw new Error(
          `Transmission ${transmissionId} belongs to ${transmission.areaId}, expected ${area.areaId}.`,
        )
      }
    }
  }

  // 現行の探索は 1 枚の連続マップ前提です。別 mapId を混ぜると移動・表示・進行の前提が崩れます。
  if (areaMapIds.size > 1) {
    throw new Error(`Expected a single shared world map, found ${areaMapIds.size} mapIds.`)
  }

  for (const transmission of Object.values(bundle.transmissions)) {
    const area = bundle.areas[transmission.areaId]
    if (!area) {
      throw new Error(
        `Missing area ${transmission.areaId} for transmission ${transmission.transmissionId}.`,
      )
    }
    if (!area.transmissionIds.includes(transmission.transmissionId)) {
      throw new Error(
        `Area ${area.areaId} does not list transmission ${transmission.transmissionId}.`,
      )
    }

    assertConditionExists(
      bundle,
      transmission.visibilityConditionId,
      `transmission ${transmission.transmissionId}`,
    )
    assertConditionExists(
      bundle,
      transmission.accessConditionId,
      `transmission ${transmission.transmissionId}`,
    )
    assertConditionExists(
      bundle,
      transmission.unlockConditionId,
      `transmission ${transmission.transmissionId}`,
    )
    if (!bundle.missions[transmission.missionId]) {
      throw new Error(
        `Missing mission ${transmission.missionId} for transmission ${transmission.transmissionId}.`,
      )
    }

    for (const rewardEquipmentId of transmission.rewardEquipmentIds ?? []) {
      if (!bundle.equipment[rewardEquipmentId]) {
        throw new Error(
          `Missing reward equipment ${rewardEquipmentId} for transmission ${transmission.transmissionId}.`,
        )
      }
    }

    let previousChunkEndMs = -Infinity
    for (const chunkId of transmission.transcriptChunkIds) {
      const chunk = bundle.transcriptChunks[chunkId]
      if (!chunk) {
        throw new Error(`Missing transcript chunk ${chunkId} for transmission ${transmission.transmissionId}.`)
      }

      if (chunk.transmissionId !== transmission.transmissionId) {
        throw new Error(
          `Transcript chunk ${chunkId} belongs to ${chunk.transmissionId}, expected ${transmission.transmissionId}.`,
        )
      }
      if (chunk.endMs <= chunk.startMs) {
        throw new Error(`Transcript chunk ${chunkId} must have endMs greater than startMs.`)
      }
      if (chunk.startMs < previousChunkEndMs) {
        throw new Error(`Transcript chunk ${chunkId} overlaps previous chunk in ${transmission.transmissionId}.`)
      }
      assertTranscriptChunkRecovery(chunk)
      previousChunkEndMs = chunk.endMs
    }
  }

  for (const mission of Object.values(bundle.missions)) {
    assertConditionExists(bundle, mission.visibilityConditionId, `mission ${mission.missionId}`)
    assertConditionExists(bundle, mission.startConditionId, `mission ${mission.missionId}`)
    if (!bundle.transmissions[mission.transmissionId]) {
      throw new Error(
        `Missing transmission ${mission.transmissionId} for mission ${mission.missionId}.`,
      )
    }

    if (!validSpawnPointIds.has(mission.playerSpawnId)) {
      throw new Error(
        `Unsupported player spawn ${mission.playerSpawnId} in mission ${mission.missionId}.`,
      )
    }
    assertFragmentRecoveryTuning(mission)

    for (const wave of mission.waves) {
      for (const entry of wave.entries) {
        if (!bundle.enemies[entry.enemyId]) {
          throw new Error(
            `Missing enemy ${entry.enemyId} in mission ${mission.missionId}.`,
          )
        }
        if (!validSpawnPointIds.has(entry.spawnPointId)) {
          throw new Error(
            `Unsupported enemy spawn ${entry.spawnPointId} in mission ${mission.missionId}.`,
          )
        }
        for (const key of Object.keys(entry.overrides ?? {})) {
          if (!SUPPORTED_ENEMY_OVERRIDE_KEYS.has(key)) {
            throw new Error(
              `Unsupported enemy override ${key} in mission ${mission.missionId}.`,
            )
          }
        }
      }
    }

    for (const hazard of mission.hazards) {
      assertConditionExists(bundle, hazard.visibilityConditionId, `hazard ${hazard.hazardId}`)
      if (hazard.area.width <= 0 || hazard.area.height <= 0) {
        throw new Error(`Hazard ${hazard.hazardId} in mission ${mission.missionId} has invalid area.`)
      }
      if (
        hazard.motion.motionKind === "linear" &&
        !Number.isFinite(hazard.motion.velocity.x + hazard.motion.velocity.y)
      ) {
        throw new Error(`Hazard ${hazard.hazardId} in mission ${mission.missionId} has invalid velocity.`)
      }
    }
  }

  for (const enemy of Object.values(bundle.enemies)) {
    if (!SUPPORTED_ENEMY_BEHAVIOR_KINDS.has(enemy.behaviorKind)) {
      throw new Error(`Unsupported behavior ${enemy.behaviorKind} for enemy ${enemy.enemyId}.`)
    }
    for (const bulletPatternId of enemy.bulletPatternIds) {
      if (!bundle.bulletPatterns[bulletPatternId]) {
        throw new Error(
          `Missing bullet pattern ${bulletPatternId} for enemy ${enemy.enemyId}.`,
        )
      }
    }
  }

  for (const bulletPattern of Object.values(bundle.bulletPatterns)) {
    if (!SUPPORTED_BULLET_PATTERN_KINDS.has(bulletPattern.patternKind)) {
      throw new Error(
        `Unsupported pattern kind ${bulletPattern.patternKind} for ${bulletPattern.bulletPatternId}.`,
      )
    }
    if (!bundle.projectiles[bulletPattern.projectileId]) {
      throw new Error(
        `Missing projectile ${bulletPattern.projectileId} for pattern ${bulletPattern.bulletPatternId}.`,
      )
    }
  }

  for (const equipment of Object.values(bundle.equipment)) {
    if (!equipment.summary?.trim()) {
      throw new Error(`Missing summary for equipment ${equipment.equipmentId}.`)
    }

    assertConditionExists(bundle, equipment.unlockConditionId, `equipment ${equipment.equipmentId}`)
    assertConditionExists(
      bundle,
      equipment.visibilityConditionId,
      `equipment ${equipment.equipmentId}`,
    )

    if (
      equipment.unlockSource.kind === "transmissionReward" &&
      !bundle.transmissions[equipment.unlockSource.transmissionId]
    ) {
      throw new Error(
        `Missing transmission ${equipment.unlockSource.transmissionId} for equipment ${equipment.equipmentId}.`,
      )
    }

    if (
      equipment.unlockSource.kind === "mapPickup" &&
      !validNodeIds.has(equipment.unlockSource.nodeId)
    ) {
      throw new Error(
        `Missing collectible node ${equipment.unlockSource.nodeId} for equipment ${equipment.equipmentId}.`,
      )
    }

    for (const effectId of [...equipment.passiveEffectIds, ...equipment.activeEffectIds]) {
      if (!bundle.effects[effectId]) {
        throw new Error(
          `Missing effect ${effectId} for equipment ${equipment.equipmentId}.`,
        )
      }
    }
  }

  for (const mapLogic of Object.values(bundle.mapLogic)) {
    for (const node of mapLogic.areaNodes) {
      if (!bundle.areas[node.areaId]) {
        throw new Error(`Missing area ${node.areaId} for node ${node.nodeId}.`)
      }
      assertConditionExists(bundle, node.visibilityConditionId, `node ${node.nodeId}`)
    }

    for (const node of mapLogic.transmissionNodes) {
      if (!bundle.transmissions[node.transmissionId]) {
        throw new Error(`Missing transmission ${node.transmissionId} for node ${node.nodeId}.`)
      }
      if (!bundle.areas[node.areaId]) {
        throw new Error(`Missing area ${node.areaId} for node ${node.nodeId}.`)
      }
      assertConditionExists(bundle, node.visibilityConditionId, `node ${node.nodeId}`)
      assertConditionExists(bundle, node.accessConditionId, `node ${node.nodeId}`)
      assertSignalProfile(node.signalProfile, `node ${node.nodeId}`)
    }

    for (const node of mapLogic.warpNodes) {
      if (!bundle.areas[node.areaId]) {
        throw new Error(`Missing area ${node.areaId} for node ${node.nodeId}.`)
      }
      if (!bundle.areas[node.warpTargetAreaId]) {
        throw new Error(`Missing warp target area ${node.warpTargetAreaId} for node ${node.nodeId}.`)
      }
      assertConditionExists(bundle, node.visibilityConditionId, `node ${node.nodeId}`)
      assertConditionExists(bundle, node.accessConditionId, `node ${node.nodeId}`)
    }

    for (const node of mapLogic.collectibleNodes) {
      if (!bundle.areas[node.areaId]) {
        throw new Error(`Missing area ${node.areaId} for node ${node.nodeId}.`)
      }
      if (node.collectibleKind === "hiddenEquipment" && node.equipmentId && !bundle.equipment[node.equipmentId]) {
        throw new Error(`Missing equipment ${node.equipmentId} for collectible ${node.nodeId}.`)
      }
      assertConditionExists(bundle, node.visibilityConditionId, `node ${node.nodeId}`)
      assertSignalProfile(node.signalProfile, `node ${node.nodeId}`)
    }
  }

  for (const condition of Object.values(bundle.conditions)) {
    switch (condition.kind) {
      case "always":
      case "flagSet":
      case "saveSlotUsed":
        break
      case "all":
      case "any":
        for (const childId of condition.children) {
          assertConditionExists(bundle, childId, `condition ${condition.conditionId}`)
        }
        break
      case "not":
        assertConditionExists(bundle, condition.child, `condition ${condition.conditionId}`)
        break
      case "equipmentEquipped":
        if (condition.equipmentId && !bundle.equipment[condition.equipmentId]) {
          throw new Error(
            `Missing equipment ${condition.equipmentId} for condition ${condition.conditionId}.`,
          )
        }
        break
      case "missionCleared":
        if (!bundle.missions[condition.missionId]) {
          throw new Error(
            `Missing mission ${condition.missionId} for condition ${condition.conditionId}.`,
          )
        }
        break
      case "areaDiscovered":
        if (!bundle.areas[condition.areaId]) {
          throw new Error(
            `Missing area ${condition.areaId} for condition ${condition.conditionId}.`,
          )
        }
        break
      case "analysisAtLeast":
      case "restorationAtLeast":
        if (!bundle.transmissions[condition.transmissionId]) {
          throw new Error(
            `Missing transmission ${condition.transmissionId} for condition ${condition.conditionId}.`,
          )
        }
        break
      case "collectibleCollected":
        if (!validNodeIds.has(condition.nodeId)) {
          throw new Error(
            `Missing node ${condition.nodeId} for condition ${condition.conditionId}.`,
          )
        }
        break
    }
  }

  assertEffectProjectileReferences(bundle)
  assertMigrationMapTargets(bundle, validNodeIds)
}

function assertEffectProjectileReferences(bundle: ContentBundle): void {
  const projectileReferenceKeys = [
    "projectileId",
    "meleeProjectileId",
    "explosionVisualProjectileId",
  ]

  for (const effect of Object.values(bundle.effects)) {
    for (const key of projectileReferenceKeys) {
      const projectileId = effect.params?.[key]
      if (typeof projectileId !== "string") {
        continue
      }
      if (!bundle.projectiles[projectileId]) {
        throw new Error(`Missing projectile ${projectileId} for effect ${effect.effectId}.${key}.`)
      }
    }
  }
}

function assertMigrationMapTargets(
  bundle: ContentBundle,
  validNodeIds: Set<string>,
): void {
  assertMigrationTargets(bundle.migratedIds.areas, bundle.areas, "area")
  assertMigrationTargets(bundle.migratedIds.transmissions, bundle.transmissions, "transmission")
  assertMigrationTargets(bundle.migratedIds.missions, bundle.missions, "mission")
  assertMigrationTargets(bundle.migratedIds.equipment, bundle.equipment, "equipment")
  assertMigrationTargets(bundle.migratedIds.enemies, bundle.enemies, "enemy")
  assertMigrationTargets(bundle.migratedIds.bulletPatterns, bundle.bulletPatterns, "bullet pattern")
  assertMigrationTargets(bundle.migratedIds.projectiles, bundle.projectiles, "projectile")

  for (const [sourceId, targetId] of Object.entries(bundle.migratedIds.worldMapNodes)) {
    if (!validNodeIds.has(targetId)) {
      throw new Error(`Migration target node ${targetId} for ${sourceId} does not exist.`)
    }
  }
}

function assertMigrationTargets<T>(
  mappings: Record<string, string>,
  targetIndex: Record<string, T>,
  label: string,
): void {
  for (const [sourceId, targetId] of Object.entries(mappings)) {
    if (!targetIndex[targetId]) {
      throw new Error(`Migration target ${label} ${targetId} for ${sourceId} does not exist.`)
    }
  }
}

function assertTranscriptChunkRecovery(chunk: TranscriptChunk): void {
  const importance = chunk.importance
  if (importance && !SUPPORTED_TRANSCRIPT_IMPORTANCE.has(importance)) {
    throw new Error(`Unsupported importance ${importance} for transcript chunk ${chunk.chunkId}.`)
  }

  const recovery = chunk.fragmentRecovery
  if (!recovery) {
    return
  }

  assertPositiveNumber(recovery.weight, `fragmentRecovery.weight for transcript chunk ${chunk.chunkId}`)
  assertRate(recovery.minSpanRatio, `fragmentRecovery.minSpanRatio for transcript chunk ${chunk.chunkId}`)
  assertRate(recovery.maxSpanRatio, `fragmentRecovery.maxSpanRatio for transcript chunk ${chunk.chunkId}`)
  assertPositiveNumber(
    recovery.lifetimeMultiplier,
    `fragmentRecovery.lifetimeMultiplier for transcript chunk ${chunk.chunkId}`,
  )
  if (
    recovery.minSpanRatio !== undefined &&
    recovery.maxSpanRatio !== undefined &&
    recovery.minSpanRatio > recovery.maxSpanRatio
  ) {
    throw new Error(`Transcript chunk ${chunk.chunkId} has minSpanRatio greater than maxSpanRatio.`)
  }
}

function assertFragmentRecoveryTuning(mission: MissionMaster): void {
  const tuning = mission.fragmentRecovery
  if (!tuning) {
    return
  }

  assertPositiveNumber(tuning.cooldownMs, `fragmentRecovery.cooldownMs for mission ${mission.missionId}`)
  assertPositiveNumber(
    tuning.spawnDistanceMin,
    `fragmentRecovery.spawnDistanceMin for mission ${mission.missionId}`,
  )
  assertPositiveNumber(
    tuning.spawnDistanceMax,
    `fragmentRecovery.spawnDistanceMax for mission ${mission.missionId}`,
  )
  assertRate(tuning.minSpanRatio, `fragmentRecovery.minSpanRatio for mission ${mission.missionId}`)
  assertRate(tuning.maxSpanRatio, `fragmentRecovery.maxSpanRatio for mission ${mission.missionId}`)
  if (
    tuning.spawnDistanceMin !== undefined &&
    tuning.spawnDistanceMax !== undefined &&
    tuning.spawnDistanceMin > tuning.spawnDistanceMax
  ) {
    throw new Error(`Mission ${mission.missionId} has spawnDistanceMin greater than spawnDistanceMax.`)
  }
  if (
    tuning.minSpanRatio !== undefined &&
    tuning.maxSpanRatio !== undefined &&
    tuning.minSpanRatio > tuning.maxSpanRatio
  ) {
    throw new Error(`Mission ${mission.missionId} has minSpanRatio greater than maxSpanRatio.`)
  }
  for (const [difficulty, lifetimeMs] of Object.entries(tuning.lifetimeMs ?? {})) {
    if (difficulty !== "calm" && difficulty !== "terminal") {
      throw new Error(`Mission ${mission.missionId} has unsupported fragment lifetime difficulty ${difficulty}.`)
    }
    assertPositiveNumber(lifetimeMs, `fragmentRecovery.lifetimeMs.${difficulty} for mission ${mission.missionId}`)
  }
}

function assertSignalProfile(profile: SignalProfile | undefined, ownerLabel: string): void {
  if (!profile) {
    return
  }

  assertPositiveNumber(profile.passiveRadius, `signalProfile.passiveRadius for ${ownerLabel}`)
  assertPositiveNumber(
    profile.passiveConfidenceRadius,
    `signalProfile.passiveConfidenceRadius for ${ownerLabel}`,
  )
  assertPositiveNumber(profile.scanRadius, `signalProfile.scanRadius for ${ownerLabel}`)
  assertPositiveNumber(
    profile.confidenceMultiplier,
    `signalProfile.confidenceMultiplier for ${ownerLabel}`,
  )
  assertPositiveNumber(
    profile.hintStrengthMultiplier,
    `signalProfile.hintStrengthMultiplier for ${ownerLabel}`,
  )
}

function assertPositiveNumber(value: number | undefined, ownerLabel: string): void {
  if (value === undefined) {
    return
  }
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`${ownerLabel} must be a positive number.`)
  }
}

function assertRate(value: number | undefined, ownerLabel: string): void {
  if (value === undefined) {
    return
  }
  if (!Number.isFinite(value) || value < 0 || value > 1) {
    throw new Error(`${ownerLabel} must be between 0 and 1.`)
  }
}

function assertConditionExists(
  bundle: ContentBundle,
  conditionId: ConditionId | undefined,
  ownerLabel: string,
): void {
  if (!conditionId) {
    return
  }

  if (!bundle.conditions[conditionId]) {
    throw new Error(`Missing condition ${conditionId} for ${ownerLabel}.`)
  }
}

function indexBy<
  Item extends Record<Key, string>,
  Key extends keyof Item,
>(
  key: Key,
  items: Item[],
): Record<Item[Key] & string, Item> {
  const indexed: Record<string, Item> = {}

  for (const item of items) {
    const id = item[key]
    if (indexed[id]) {
      throw new Error(`Duplicate content id detected: ${id}`)
    }
    indexed[id] = item
  }

  return indexed as Record<Item[Key] & string, Item>
}
