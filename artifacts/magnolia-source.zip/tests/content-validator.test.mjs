import assert from "node:assert/strict"
import { spawnSync } from "node:child_process"
import path from "node:path"
import { test } from "node:test"

const rootDir = path.resolve(import.meta.dirname, "..")
const validatorPath = path.join(rootDir, "tools", "content-validator", "validate-content.mjs")

test("current gameplay content passes validation", () => {
  const result = runValidator()

  assert.equal(result.status, 0, result.stderr)
  assert.match(result.stdout, /content validation passed/)
})

test("invalid fixture reports a missing mission reference", () => {
  const fixtureDir = path.join(
    "tools",
    "content-validator",
    "fixtures",
    "missing-reference",
    "content",
    "gameplay",
  )
  const result = runValidator(["--gameplay-dir", fixtureDir])

  assert.notEqual(result.status, 0)
  assert.match(result.stderr, /Missing mission 'mission_missing'/)
})

function runValidator(args = []) {
  // Spawn the command exactly as package scripts do, so fixture tests cover CLI wiring too.
  return spawnSync(process.execPath, [validatorPath, ...args], {
    cwd: rootDir,
    encoding: "utf8",
  })
}
